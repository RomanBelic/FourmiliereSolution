﻿using LibAbstraite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibMetier
{
    public class Oeuf : ObjetAbstrait
    {
        public Oeuf(int Id) : base(Id, "Oeuf")
        {
        }

        protected override object KeyComparer => Id;
    }
}
